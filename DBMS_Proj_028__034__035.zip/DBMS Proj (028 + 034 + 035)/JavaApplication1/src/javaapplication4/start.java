/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package javaapplication4;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Home
 */
public class start extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public start() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        progressbar = new javax.swing.JProgressBar();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("DBMS");
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 204, 204));
        jLabel1.setText("TechShop Database");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 30, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication4/tech.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 130, 130));
        getContentPane().add(progressbar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 540, 10));

        jLabel5.setBackground(new java.awt.Color(0, 102, 102));
        jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 540, 310));

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 540, 300));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

        static String Database_Name = "Techshop2";
        static String Desktop_Instance = "DESKTOP-JUO76V0";
        static String Desktop_Instance2 = "DAWID";
        
        static String username ="sa";
        static String password = "123";
        static String url = "jdbc:sqlserver://localhost\\"+Desktop_Instance+"+:1433;databaseName="+Database_Name+";encrypt=true;trustServerCertificate=true;";
        
        Connection con=null;
        Statement st = null;
        ResultSet rs = null;
        
        
        
    public static void main(String args[]) {
        start s = new start();
        s.setVisible(true);
        try{
        for(int i=0;i<=100;i++){
        Thread.sleep(17);
        s.progressbar.setValue(i);
        //s.Percentage.setText(Integer.toString(i)+"%");
        }}
        catch(Exception e){
                
                }
        new login().setVisible(true);
        s.dispose();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JProgressBar progressbar;
    // End of variables declaration//GEN-END:variables
}
