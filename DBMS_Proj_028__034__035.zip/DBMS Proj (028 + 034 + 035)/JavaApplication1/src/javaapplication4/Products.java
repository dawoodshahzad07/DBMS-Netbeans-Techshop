/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package javaapplication4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Home
 */
public class Products extends javax.swing.JFrame {

    public Products() {
        initComponents();
        computer_table();
    }


    boolean onPC = false;
    boolean onParts = false;
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        convert = new javax.swing.JTextField();
        description = new javax.swing.JTextField();
        price = new javax.swing.JTextField();
        type = new javax.swing.JTextField();
        Add = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        parts = new javax.swing.JButton();
        company = new javax.swing.JTextField();
        warranty = new javax.swing.JButton();
        clear1 = new javax.swing.JButton();
        convertBtn = new javax.swing.JButton();
        prodid1 = new javax.swing.JTextField();
        pc = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153), 4));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane3MouseClicked(evt);
            }
        });

        table.setBackground(new java.awt.Color(153, 153, 153));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "customerid", "PRICE", "Company", "Type", "Description"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.setRowHeight(25);
        table.setSelectionBackground(new java.awt.Color(255, 102, 0));
        table.setSelectionForeground(new java.awt.Color(255, 255, 255));
        table.setShowGrid(true);
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(table);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 720, 256));

        jLabel5.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 153, 153));
        jLabel5.setText("PRODID");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 80, 30));

        jLabel2.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 153, 153));
        jLabel2.setText("COMPANY");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 80, 30));

        jLabel6.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 153));
        jLabel6.setText("PRICE");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, -1, 30));

        jLabel7.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 153));
        jLabel7.setText("TYPE");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 70, -1, 30));

        jLabel8.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 153, 153));
        jLabel8.setText("DESCRIPTION");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 102, 30));

        convert.setBackground(new java.awt.Color(102, 102, 102));
        convert.setForeground(new java.awt.Color(255, 255, 255));
        convert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                convertActionPerformed(evt);
            }
        });
        jPanel3.add(convert, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 80, 30));

        description.setBackground(new java.awt.Color(102, 102, 102));
        description.setForeground(new java.awt.Color(255, 255, 255));
        description.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descriptionActionPerformed(evt);
            }
        });
        jPanel3.add(description, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 120, 507, 49));

        price.setBackground(new java.awt.Color(102, 102, 102));
        price.setForeground(new java.awt.Color(255, 255, 255));
        price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priceActionPerformed(evt);
            }
        });
        jPanel3.add(price, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, 170, 30));

        type.setBackground(new java.awt.Color(102, 102, 102));
        type.setForeground(new java.awt.Color(255, 255, 255));
        type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                typeActionPerformed(evt);
            }
        });
        jPanel3.add(type, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 70, 170, 30));

        Add.setBackground(new java.awt.Color(0, 102, 102));
        Add.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        Add.setForeground(new java.awt.Color(255, 255, 255));
        Add.setText("ADD");
        Add.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddMouseClicked(evt);
            }
        });
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        jPanel3.add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, 100, 38));

        edit.setBackground(new java.awt.Color(0, 102, 102));
        edit.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        edit.setForeground(new java.awt.Color(255, 255, 255));
        edit.setText("EDIT");
        edit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editMouseClicked(evt);
            }
        });
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });
        jPanel3.add(edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, 100, 38));

        delete.setBackground(new java.awt.Color(0, 102, 102));
        delete.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        delete.setForeground(new java.awt.Color(255, 255, 255));
        delete.setText("DELETE");
        delete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteMouseClicked(evt);
            }
        });
        jPanel3.add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 230, 100, 38));

        parts.setBackground(new java.awt.Color(153, 153, 0));
        parts.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        parts.setForeground(new java.awt.Color(255, 255, 255));
        parts.setText("Show PC Parts");
        parts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                partsActionPerformed(evt);
            }
        });
        jPanel3.add(parts, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 180, 140, 38));

        company.setBackground(new java.awt.Color(102, 102, 102));
        company.setForeground(new java.awt.Color(255, 255, 255));
        company.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyActionPerformed(evt);
            }
        });
        jPanel3.add(company, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, 170, 30));

        warranty.setBackground(new java.awt.Color(0, 102, 102));
        warranty.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        warranty.setForeground(new java.awt.Color(255, 255, 255));
        warranty.setText("CHECK WARRANTY");
        warranty.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                warrantyMouseClicked(evt);
            }
        });
        warranty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                warrantyActionPerformed(evt);
            }
        });
        jPanel3.add(warranty, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 230, 142, 38));

        clear1.setBackground(new java.awt.Color(0, 102, 102));
        clear1.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        clear1.setForeground(new java.awt.Color(255, 255, 255));
        clear1.setText("CLEAR");
        clear1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear1ActionPerformed(evt);
            }
        });
        jPanel3.add(clear1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 230, 100, 38));

        convertBtn.setBackground(new java.awt.Color(0, 102, 102));
        convertBtn.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        convertBtn.setForeground(new java.awt.Color(255, 255, 255));
        convertBtn.setText("Convert Price");
        convertBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                convertBtnMouseClicked(evt);
            }
        });
        jPanel3.add(convertBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 285, 120, 38));

        prodid1.setBackground(new java.awt.Color(102, 102, 102));
        prodid1.setForeground(new java.awt.Color(255, 255, 255));
        prodid1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prodid1ActionPerformed(evt);
            }
        });
        jPanel3.add(prodid1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 170, 30));

        pc.setBackground(new java.awt.Color(153, 153, 0));
        pc.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        pc.setForeground(new java.awt.Color(255, 255, 255));
        pc.setText("Show PCs");
        pc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pcActionPerformed(evt);
            }
        });
        jPanel3.add(pc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 180, 140, 38));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-8, 58, 740, 620));

        jButton1.setBackground(new java.awt.Color(0, 102, 102));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 51, 51));
        jButton1.setText("X");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        jButton1.setContentAreaFilled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(668, 0, 69, -1));

        jButton2.setBackground(new java.awt.Color(0, 102, 102));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(153, 153, 0));
        jButton2.setText("GO BACK");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 2));
        jButton2.setContentAreaFilled(false);
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 94, 38));

        jLabel4.setBackground(new java.awt.Color(0, 102, 102));
        jLabel4.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 153));
        jLabel4.setText("Manage Products");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-1, -2, 740, 690));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 700));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void convertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convertActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_convertActionPerformed

    private void descriptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descriptionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_descriptionActionPerformed

    private void priceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_priceActionPerformed

    private void typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_typeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_typeActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton1ActionPerformed
Connection con=null;
Statement st = null;
ResultSet rs = null;

    public void computer_table(){
        
        try{
        con = DriverManager.getConnection(start.url,start.username, start.password);
        st=con.createStatement();
        rs=st.executeQuery("select * from Computer");
        table.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(SQLException e){
         e.printStackTrace();
        }
}
    
     public void parts_table(){
        
        try{
        con = DriverManager.getConnection(start.url,start.username, start.password);
        st=con.createStatement();
        rs=st.executeQuery("select * from Parts");
        table.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(SQLException e){
         e.printStackTrace();
        }
}
    
    
    
    private void AddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddMouseClicked

        if(price.getText().isEmpty()||company.getText().isEmpty()||type.getText().isEmpty()||description.getText().isEmpty()){
        JOptionPane.showMessageDialog(this,"Missing Information");
        }
        else{
        try{
        con = DriverManager.getConnection(start.url,start.username, start.password);
        
        PreparedStatement add=con.prepareStatement("insert into Computer values(?,?,?,?,?,?)");
        add.setInt(1, Integer.valueOf(convert.getText()));
        add.setString(2,null);
        add.setInt(3, Integer.valueOf(price.getText()));
        add.setString(4,company.getText());
        add.setString(5,type.getText());
        add.setString(6,description.getText());
       
        int row= add.executeUpdate();
        JOptionPane.showMessageDialog(this,"Product Added Successfully");
        con.close();
        computer_table();
        }
        catch(SQLException e){
        e.printStackTrace();
        }}
    }//GEN-LAST:event_AddMouseClicked
    
    private void companyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyActionPerformed

    private void jScrollPane3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jScrollPane3MouseClicked

    private void partsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_partsActionPerformed
        
        onPC = false;
        onParts = true;
        
        parts_table();
    }//GEN-LAST:event_partsActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        // TODO add your handling code here:
                DefaultTableModel model = (DefaultTableModel) table.getModel();
         int index = table.getSelectedRow();
         convert.setText(model.getValueAt(index,0).toString());
          price.setText(model.getValueAt(index,2).toString());
         company.setText(model.getValueAt(index,3).toString());
          type.setText(model.getValueAt(index,4).toString());
           description.setText(model.getValueAt(index,5).toString());
  
    }//GEN-LAST:event_tableMouseClicked

    private void deleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMouseClicked
        // TODO add your handling code here:
        try{
        con = DriverManager.getConnection(start.url,start.username, start.password);
        String id = convert.getText();
        String query = "Delete from Computer where id ="+id;
        Statement add = con.createStatement();
        add.execute(query);
        computer_table();
        
        }
        catch(Exception e){
      e.printStackTrace();
        }
    }//GEN-LAST:event_deleteMouseClicked

    private void editMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editMouseClicked
        // TODO add your handling code here:
        try{
        con = DriverManager.getConnection(start.url,start.username, start.password);
        String query = "update Computer set price='"+price.getText()+"',company='"+company.getText()+"',Type='"+type.getText()+"',description='"+description.getText()+"' "+"where id="+convert.getText();
        Statement add = con.createStatement();
        add.executeUpdate(query);
        computer_table();
         JOptionPane.showMessageDialog(this,"Updated Successfully");
        }
        catch(Exception e){
      e.printStackTrace();
        }
    }//GEN-LAST:event_editMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        // TODO add your handling code here:
        dispose();
        AdminSelect a = new AdminSelect();
        a.setVisible(true);
        
    }//GEN-LAST:event_jButton2MouseClicked

    private void warrantyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_warrantyActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_warrantyActionPerformed

    private void warrantyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_warrantyMouseClicked

        try{
            con = DriverManager.getConnection(start.url,start.username, start.password);
            st=con.createStatement();
            rs=st.executeQuery("Select c.id as Computer_ID, Company, w.description as Warranty_Details, price, c.description\n" +
                                "FROM Computer c\n" +
                                "JOIN Warranty w ON c.id = w.computer_id");
            table.setModel(DbUtils.resultSetToTableModel(rs));
            }
        catch(SQLException e){
         e.printStackTrace();
        }
    }//GEN-LAST:event_warrantyMouseClicked

    private void clear1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear1ActionPerformed
        // TODO add your handling code here:
        convert.setText("");
         price.setText("");
          company.setText("");
          type.setText("");
          description.setText("");
    }//GEN-LAST:event_clear1ActionPerformed

    private void convertBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_convertBtnMouseClicked
        // TODO add your handling code here:
        
        try{
        con = DriverManager.getConnection(start.url,start.username, start.password);
        st=con.createStatement();
        
        String currency = convert.getText();
        
        if(onPC)
            rs=st.executeQuery("Select * from PriceConvertPC('"+(currency.toUpperCase())+"')");
        else if(onParts)
            rs=st.executeQuery("Select * from PriceConvertPart('"+(currency.toUpperCase())+"')");
        
        table.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(SQLException e){
         e.printStackTrace();
        }
        
    }//GEN-LAST:event_convertBtnMouseClicked

    private void prodid1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prodid1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prodid1ActionPerformed

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AddActionPerformed

    private void pcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pcActionPerformed
        // TODO add your handling code here:
        onPC = true;
        onParts = false;
        
        computer_table();
        
    }//GEN-LAST:event_pcActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Products().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton clear1;
    private javax.swing.JTextField company;
    private javax.swing.JTextField convert;
    private javax.swing.JButton convertBtn;
    private javax.swing.JButton delete;
    private javax.swing.JTextField description;
    private javax.swing.JButton edit;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton parts;
    private javax.swing.JButton pc;
    private javax.swing.JTextField price;
    private javax.swing.JTextField prodid1;
    private javax.swing.JTable table;
    private javax.swing.JTextField type;
    private javax.swing.JButton warranty;
    // End of variables declaration//GEN-END:variables
}
